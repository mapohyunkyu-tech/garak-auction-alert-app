package kr.garak.auctionalert;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Our Cloudflare-rendered auction price list, inside the app (not the OZ viewer). */
public class DetailActivity extends Activity {
    private WebView browser;
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private boolean isOurDetail(Uri u){
        return u!=null && "https".equalsIgnoreCase(u.getScheme()) &&
            "garak-auction-alert.mapohyunkyu.workers.dev".equalsIgnoreCase(u.getHost()) &&
            ("/detail".equals(u.getPath()) || "/watch".equals(u.getPath()));
    }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        String raw=getIntent().getStringExtra("url");
        Uri url=raw==null?null:Uri.parse(raw);
        if(!isOurDetail(url)){finish();return;}

        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        LinearLayout top=new LinearLayout(this);
        top.setGravity(android.view.Gravity.CENTER_VERTICAL);
        top.setPadding(dp(8),dp(4),dp(12),dp(4));
        Button back=new Button(this);back.setText("← 목록");back.setOnClickListener(v->finish());
        top.addView(back);
        TextView heading=new TextView(this);
        heading.setText("경락가격 상세 · 높은 가격순");
        heading.setTextColor(0xff173544);
        heading.setTextSize(16);
        top.addView(heading,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(top);
        browser=new WebView(this);
        browser.getSettings().setJavaScriptEnabled(false);
        browser.getSettings().setDomStorageEnabled(false);
        browser.getSettings().setAllowFileAccess(false);
        browser.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
                Uri link=request.getUrl();
                if(isOurDetail(link))return false;
                if("https".equalsIgnoreCase(link.getScheme())){
                    startActivity(new Intent(Intent.ACTION_VIEW,link));
                }
                return true;
            }
        });
        root.addView(browser,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        browser.loadUrl(url.toString());
    }
    @Override public void onBackPressed(){
        if(browser!=null && browser.canGoBack())browser.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy(){
        if(browser!=null){browser.destroy();browser=null;}
        super.onDestroy();
    }
}
