package kr.garak.auctionalert;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Best-effort direct-device test receipt/opened acknowledgments. */
public final class TestReporter {
    private TestReporter() {}
    public static void ack(Context ctx,String testId,String stage) {
        if(testId==null||!testId.matches("[0-9a-f]{64}")||
           !("received".equals(stage)||"opened".equals(stage)))return;
        Context app=ctx.getApplicationContext();
        new Thread(()->{
            HttpURLConnection conn=null;
            try {
                SharedPreferences p=app.getSharedPreferences("favorites_v2",Context.MODE_PRIVATE);
                String id=p.getString("client_id_v4", "");
                String secret=p.getString("client_secret_v4", "");
                if(id.isEmpty()||secret.length()!=64)return;
                JSONObject body=new JSONObject();
                body.put("client_id",id);body.put("client_secret",secret);
                body.put("test_id",testId);body.put("stage",stage);
                conn=(HttpURLConnection)new URL("https://garak-auction-alert.mapohyunkyu.workers.dev/api/test/ack").openConnection();
                conn.setConnectTimeout(8000);conn.setReadTimeout(8000);
                conn.setRequestMethod("POST");conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type","application/json; charset=UTF-8");
                try(OutputStream stream=conn.getOutputStream()){
                    stream.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }
                conn.getResponseCode();
            } catch(Exception ignored) { /* status page will reflect unconfirmed ACK */ }
            finally {if(conn!=null)conn.disconnect();}
        },"garak-diagnostic-ack").start();
    }
}
