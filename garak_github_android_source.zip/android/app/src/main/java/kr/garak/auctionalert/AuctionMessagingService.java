package kr.garak.auctionalert;

import android.app.PendingIntent;
import android.content.Intent;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class AuctionMessagingService extends FirebaseMessagingService {
    @Override public void onMessageReceived(RemoteMessage message) {
        // 앱 실행 중 도착한 알림은 펼쳐 볼 수 있도록 BigTextStyle로 표시.
        String title = message.getNotification()!=null ? message.getNotification().getTitle():"가락 경매 알림";
        String body = message.getNotification()!=null ? message.getNotification().getBody():"새 경매결과가 올라왔습니다.";
        Intent intent=new Intent(this,MainActivity.class);
        intent.setAction("kr.garak.auctionalert.OPEN_GARAK");
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pending=PendingIntent.getActivity(this,(int)(System.currentTimeMillis()%2147483647),intent,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder n=new NotificationCompat.Builder(this,"auction")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).setContentIntent(pending);
        try {NotificationManagerCompat.from(this).notify((int)(System.currentTimeMillis()%2147483647),n.build());}
        catch(SecurityException ignored) { /* 알림 권한이 없는 경우 */ }
    }
}
