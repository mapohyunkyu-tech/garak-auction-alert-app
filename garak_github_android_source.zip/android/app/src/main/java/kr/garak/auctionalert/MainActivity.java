package kr.garak.auctionalert;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends Activity {
    public static final String SITE = "https://temp.garak.co.kr/price/OZViewer.do";
    private TextView status;

    private boolean restoring = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        initChannel();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 12);
        }
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22),dp(30),dp(22),dp(20));
        root.setBackgroundColor(Color.WHITE);
        TextView title = label("가락시장 경매 알림",24,Color.BLACK);root.addView(title);
        TextView summary = label("1차 실험 · 당근 20kg · 특 등급\n새 경매결과만 알림 · 5분 간격 서버 확인",14,0xff555555);
        summary.setPadding(0,dp(14),0,dp(25)); root.addView(summary);
        makeSwitch(root,"한국청과 알림", "garak_hankook_carrot20_special", "hankook");
        makeSwitch(root,"대아청과 알림", "garak_daea_carrot20_special", "daea");
        Button button = new Button(this);button.setText("가락시장 경매결과 열기");
        button.setOnClickListener(v->openSite());root.addView(button);
        status = label("알림 허용 후 법인별 스위치를 켜세요.",14,0xff666666);
        status.setPadding(0,dp(20),0,0);root.addView(status);
        TextView note = label("알림: 특 머리(최고) / 중간(중앙값) / 꼬리(최저) / 평균(건별 산술평균).\n알림을 누르면 원본 사이트가 열립니다.",13,0xff666666);
        note.setPadding(0,dp(12),0,0);root.addView(note);
        setContentView(root);
        if (getIntent()!=null && "kr.garak.auctionalert.OPEN_GARAK".equals(getIntent().getAction())) openSite();
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);if ("kr.garak.auctionalert.OPEN_GARAK".equals(intent.getAction())) openSite();}
    private Switch makeSwitch(LinearLayout root,String title,String topic,String key){
        Switch sw=new Switch(this);sw.setText(title);sw.setTextSize(18);sw.setPadding(0,dp(12),0,dp(16));
        sw.setChecked(getPreferences(MODE_PRIVATE).getBoolean(key,false));
        sw.setOnCheckedChangeListener((button,isOn)->{
            if(restoring)return;
            // 구독 성공 이후에만 설정 저장.
            if(isOn){
                FirebaseMessaging.getInstance().subscribeToTopic(topic).addOnCompleteListener(t->{
                    if(t.isSuccessful())save(key,true,sw,title+" ON"); else revert(sw,false,"구독 실패: 네트워크/Firebase 설정 확인");
                });
            }else{
                FirebaseMessaging.getInstance().unsubscribeFromTopic(topic).addOnCompleteListener(t->{
                    if(t.isSuccessful())save(key,false,sw,title+" OFF"); else revert(sw,true,"해제 실패: 네트워크 확인");
                });
            }
        });
        root.addView(sw);return sw;
    }
    private void save(String key,boolean value,Switch sw,String text){
        getPreferences(MODE_PRIVATE).edit().putBoolean(key,value).apply();status.setText(text);
    }
    private void revert(Switch sw,boolean checked,String text){restoring=true;sw.setChecked(checked);restoring=false;status.setText(text);}
    private TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private int dp(int px){return Math.round(getResources().getDisplayMetrics().density*px);}
    private void openSite(){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(SITE)));}
    private void initChannel(){
        NotificationManager mgr=getSystemService(NotificationManager.class);
        if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel("auction","경매결과 알림",NotificationManager.IMPORTANCE_HIGH);ch.setDescription("한국청과·대아청과 당근 20kg 경매");mgr.createNotificationChannel(ch);}
    }
}
