package kr.garak.auctionalert;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.text.InputType;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.UUID;
import java.security.SecureRandom;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String API = "https://garak-auction-alert.mapohyunkyu.workers.dev";
    private static final String SITE = "https://temp.garak.co.kr/price/resultAuctionList.do?market_cd=1&menu_flag=1";
    private static final String SITE_GANGSEO = "https://temp.garak.co.kr/price/resultAuctionList.do?market_cd=3&menu_flag=1";
    private static final String[] GARAK = {"서울청과", "농협가락공판장", "중앙청과", "동화청과", "한국청과", "대아청과"};
    private static final String[] GANGSEO = {"강서청과", "서부청과", "농협강서공판장"};
    private static final String[] CORPS = {"가락시장 전체", "강서시장 전체", "서울청과", "농협가락공판장", "중앙청과", "동화청과", "한국청과", "대아청과", "강서청과", "서부청과", "농협강서공판장"};
    private static final String[] GRADES = {"특", "상", "중", "등외", "전체"};
    private static final String[] ITEMS = {
        "바나나", "사과", "배", "감귤", "오렌지", "포도", "샤인머스캣", "복숭아", "자두",
        "체리", "키위", "참다래", "딸기", "수박", "참외", "토마토", "방울토마토",
        "멜론", "레몬", "망고", "파인애플", "블루베리", "단감", "대봉", "떫은감",
        "당근", "양배추", "고구마", "감자", "표고", "오이", "양파", "쪽파", "초롱무",
        "상추", "배추", "무", "마늘", "깻잎", "부추", "시금치", "브로콜리", "파프리카"
    };
    private static final String[] UNITS = {
        "전체", "500g", "1kg", "2kg", "2.5kg", "3kg", "4kg", "5kg", "6kg", "7kg",
        "7.5kg", "8kg", "9kg", "10kg", "11kg", "12kg", "13kg", "14kg", "15kg",
        "16kg", "17kg", "18kg", "20kg", "상자", "박스", "그물망"
    };
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final ArrayList<Favorite> favorites=new ArrayList<>();
    private LinearLayout itemsView;
    private TextView status;
    private SharedPreferences prefs;
    private TextView testStatus;
    private String clientId, clientSecret;

    static class Favorite {
        String id,corp,item,unit,grade,variety,topic="";
        boolean enabled=false;
        Favorite(String c,String i,String u,String g,String v) {
            id=UUID.randomUUID().toString();corp=c;item=i;unit=u;grade=g;variety=v;
        }
        String title(){return corp+" · "+item+(variety.isEmpty()?"":" ("+variety+")")+" · "+unit+" · "+grade;}
        JSONObject json(){
            JSONObject j=new JSONObject();
            try {j.put("id",id);j.put("corp",corp);j.put("item",item);j.put("unit",unit);j.put("grade",grade);j.put("variety",variety);j.put("topic",topic);j.put("enabled",enabled);}catch(Exception ignored){}
            return j;
        }
        static Favorite from(JSONObject j){
            Favorite f=new Favorite(j.optString("corp","한국청과"),j.optString("item","당근"),j.optString("unit","20kg"),j.optString("grade","특"),j.optString("variety",""));
            f.id=j.optString("id",f.id);f.topic=j.optString("topic","");f.enabled=j.optBoolean("enabled",false);return f;
        }
    }
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("favorites_v2",MODE_PRIVATE);
        createNotificationChannel();
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},123);
        initClientIdentity();load();render();
        executor.execute(this::drainPendingUnwatches);
        // 기존 1차 시범 앱의 고정 토픽 구독은 취소한다.
        FirebaseMessaging.getInstance().unsubscribeFromTopic("garak_hankook_carrot20_special");
        FirebaseMessaging.getInstance().unsubscribeFromTopic("garak_daea_carrot20_special");
        for(Favorite f:new ArrayList<>(favorites))if(f.enabled)registerAndSubscribe(f,null,true);
        if(getIntent()!=null&&"kr.garak.auctionalert.OPEN_GARAK".equals(getIntent().getAction()))openNotificationLink(getIntent());
    }
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);if("kr.garak.auctionalert.OPEN_GARAK".equals(i.getAction()))openNotificationLink(i);}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView label(String s,int sp,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);return t;}
    private void status(String s){runOnUiThread(()->{if(status!=null)status.setText(s);});}
    private void load(){
        favorites.clear();
        try {JSONArray a=new JSONArray(prefs.getString("list","[]"));for(int n=0;n<a.length();n++)favorites.add(Favorite.from(a.getJSONObject(n)));}
        catch(Exception e){/* 손상된 즐겨찾기 데이터는 앱이 중단되지 않게 한다. */}
    }
    private void save(){JSONArray a=new JSONArray();for(Favorite f:favorites)a.put(f.json());prefs.edit().putString("list",a.toString()).apply();}
    private void render(){
        ScrollView scroll=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(23),dp(18),dp(24));root.setBackgroundColor(Color.WHITE);
        scroll.addView(root);
        TextView heading=label("가락·강서 경매 알림",24,0xff171717);root.addView(heading);
        TextView subtitle=label("가락 6곳·강서 3곳 | 전체 선택은 각 법인으로 일괄 추가",14,0xff666666);subtitle.setPadding(0,dp(8),0,dp(18));root.addView(subtitle);
        TextView diagTitle=label("푸시 연결 진단 (가짜 경매)",17,0xff173544);
        diagTitle.setPadding(0,dp(4),0,dp(6));root.addView(diagTitle);
        testStatus=label("기기 토큰 · 수신 · 클릭을 개별 확인합니다. 실제 경매자료와 섞이지 않습니다.",13,0xff455669);
        testStatus.setPadding(0,0,0,dp(6));root.addView(testStatus);
        Button testPush=new Button(this);testPush.setText("가짜 당근 경매 알림 보내기");
        testPush.setOnClickListener(v->sendFakeAuction(testPush));root.addView(testPush);
        Button testCheck=new Button(this);testCheck.setText("가짜 알림 수신 결과 확인");
        testCheck.setOnClickListener(v->fetchTestStatus());root.addView(testCheck);
        TextView diagHint=label("※ 즐겨찾기 알림 하나 이상 ON 필요. 가짜 가격: 45,000 · 43,000 · 40,000 · 38,000 · 35,000원.",12,0xff777777);
        root.addView(diagHint);
        Button historyButton=new Button(this);historyButton.setText("과거 경매 알림 내역 조회");
        historyButton.setOnClickListener(v->showHistoryFilter());root.addView(historyButton);
        Button unitsButton=new Button(this);unitsButton.setText("kg·규격 알림 누락 진단");
        unitsButton.setOnClickListener(v->showUnitDiagnostics());root.addView(unitsButton);
        Button adminButton=new Button(this);adminButton.setText("서버 구독 관리 (관리자 인증)");
        adminButton.setOnClickListener(v->askAdminKey());root.addView(adminButton);
        Button againButton=new Button(this);againButton.setText("현재 휴대폰 ON 즐겨찾기 다시 등록");
        againButton.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("알림 재등록")
            .setMessage("서버 초기화 후 또는 등록 실패 시 사용하세요. 현재 켜진 즐겨찾기를 서버와 Firebase에 다시 등록합니다.")
            .setNegativeButton("취소",null).setPositiveButton("등록",(d,w)->{
                int count=0;for(Favorite f:new ArrayList<>(favorites))if(f.enabled){count++;registerAndSubscribe(f,null,true);}
                status(count+"개 즐겨찾기 서버 재등록 요청 중…");
            }).show());root.addView(againButton);
        Button add=new Button(this);add.setText("+ 즐겨찾기 추가");add.setOnClickListener(v->showEditor(null));root.addView(add);
        itemsView=new LinearLayout(this);itemsView.setOrientation(LinearLayout.VERTICAL);root.addView(itemsView);
        Button site=new Button(this);site.setText("가락시장 경매결과 보기 (6개 법인)");site.setOnClickListener(v->openSite());root.addView(site);
        Button gangseoSite=new Button(this);gangseoSite.setText("강서시장 경매결과 보기 (3개 법인)");gangseoSite.setOnClickListener(v->openGangseoSite());root.addView(gangseoSite);
        status=label("알림은 즐겨찾기를 켠 품목에만 설정됩니다.",13,0xff555555);status.setPadding(0,dp(13),0,dp(7));root.addView(status);
        TextView hint=label("※ 서버와 Firebase 연결이 완료되어야 실제 푸시가 옵니다.\n※ 원본 OZ 보고서 뷰어는 모바일 브라우저에서 오류가 날 수 있습니다.",12,0xff777777);root.addView(hint);
        setContentView(scroll);renderItems();
    }
    private void renderItems(){
        if(itemsView==null)return;itemsView.removeAllViews();
        if(favorites.isEmpty()){
            TextView empty=label("등록한 즐겨찾기가 없어요.\n위 버튼을 눌러 품목·단위·등급을 등록하세요.",14,0xff666666);
            empty.setPadding(dp(6),dp(22),dp(6),dp(22));itemsView.addView(empty);return;
        }
        for(Favorite f:new ArrayList<>(favorites)){
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(10),dp(12),dp(10),dp(10));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(8),0,dp(8));itemsView.addView(card,lp);
            card.setBackgroundColor(0xfff1f4f7);
            TextView name=label(f.title(),16,0xff151515);card.addView(name);
            Switch sw=new Switch(this);sw.setText(f.enabled?"알림 ON":"알림 OFF");sw.setChecked(f.enabled);
            sw.setOnCheckedChangeListener((button,on)->{
                sw.setEnabled(false);
                if(on){
                    registerAndSubscribe(f,()->{sw.setEnabled(true);renderItems();},false);
                }else{
                    if(f.topic.isEmpty()) {
                        f.enabled=false;save();sw.setEnabled(true);renderItems();return;
                    }
                    FirebaseMessaging.getInstance().unsubscribeFromTopic(f.topic).addOnCompleteListener(task->{
                        sw.setEnabled(true);
                        if(task.isSuccessful()) {
                            enqueueUnwatch(f);
                            f.enabled=false;f.topic="";
                            save();renderItems();
                            status("알림 OFF · 서버 해제 요청 중");
                            executor.execute(this::drainPendingUnwatches);
                        }else{
                            status("Firebase 구독 해제 실패 · 다시 시도해 주세요");
                            renderItems();
                        }
                    });
                }
            });card.addView(sw);
            LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
            Button edit=new Button(this);edit.setText("수정");edit.setOnClickListener(v->showEditor(f));actions.addView(edit,new LinearLayout.LayoutParams(0,-2,1));
            Button remove=new Button(this);remove.setText("삭제");remove.setOnClickListener(v->new AlertDialog.Builder(this)
                .setMessage("이 즐겨찾기를 삭제할까요?")
                .setNegativeButton("취소",null).setPositiveButton("삭제",(d,w)->{
                    Runnable finish=()->{
                        if(!f.topic.isEmpty())enqueueUnwatch(f);
                        favorites.remove(f);save();renderItems();
                        status("즐겨찾기 삭제 · 서버 해제 요청 중");
                        executor.execute(this::drainPendingUnwatches);
                    };
                    if(f.enabled && !f.topic.isEmpty()){
                        FirebaseMessaging.getInstance().unsubscribeFromTopic(f.topic)
                            .addOnCompleteListener(task->{
                                if(task.isSuccessful())finish.run();
                                else status("구독 해제 실패 · 삭제하지 않았어요. 다시 시도해 주세요");
                            });
                    }else finish.run();
                }).show());actions.addView(remove,new LinearLayout.LayoutParams(0,-2,1));
            card.addView(actions);
            if(!f.topic.isEmpty()){
                Button details=new Button(this);details.setText("가격순 상세 보기");
                details.setOnClickListener(v->{
                    String link=API+"/watch?topic="+Uri.encode(f.topic);
                    openTrustedDetails(link);
                });
                card.addView(details);
            }
        }
    }
    private TextView fieldLabel(String text){TextView t=label(text,14,0xff333333);t.setPadding(0,dp(12),0,dp(3));return t;}
    private void showEditor(Favorite editing){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(18),0,dp(18),0);
        body.addView(fieldLabel("법인"));Spinner corp=new Spinner(this);corp.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,CORPS));
        if(editing!=null)for(int x=0;x<CORPS.length;x++)if(CORPS[x].equals(editing.corp)){corp.setSelection(x);break;}body.addView(corp);
        body.addView(fieldLabel("품목 (과일·채소 검색 또는 직접 입력)"));AutoCompleteTextView item=new AutoCompleteTextView(this);
        item.setSingleLine(true);item.setThreshold(1);item.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,ITEMS));
        item.setHint("예: 바나나, 사과, 당근");if(editing!=null)item.setText(editing.item);body.addView(item);
        body.addView(fieldLabel("품종 / 세부규격 (선택)"));EditText variety=new EditText(this);variety.setSingleLine(true);
        variety.setHint("예: 세척, 흙, 백다다기");if(editing!=null)variety.setText(editing.variety);body.addView(variety);
        body.addView(fieldLabel("kg / 단위 · 전체 선택 가능"));
        AutoCompleteTextView unit=new AutoCompleteTextView(this);
        unit.setSingleLine(true);unit.setThreshold(0);
        unit.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,UNITS));
        unit.setHint("전체 또는 5kg, 13kg 등 실제 규격");
        unit.setText(editing==null?"전체":editing.unit, false);
        unit.setOnClickListener(v->unit.showDropDown());
        body.addView(unit);
        TextView unitNote=label("전체 선택 시 모든 kg를 검색하고 가격은 규격별로 구분해 알립니다. 규격은 직접 입력도 가능합니다.",12,0xff666666);
        body.addView(unitNote);
        body.addView(fieldLabel("등급"));Spinner grade=new Spinner(this);grade.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,GRADES));
        if(editing!=null){for(int n=0;n<GRADES.length;n++)if(GRADES[n].equals(editing.grade))grade.setSelection(n);}
        else grade.setSelection(GRADES.length-1);
        body.addView(grade);
        ScrollView sc=new ScrollView(this);sc.addView(body);
        new AlertDialog.Builder(this).setTitle(editing==null?"즐겨찾기 추가":"즐겨찾기 수정")
            .setView(sc).setNegativeButton("취소",null)
            .setPositiveButton("저장",(d,w)->{
                String i=item.getText().toString().trim(),u=unit.getText().toString().trim(),v=variety.getText().toString().trim();
                if(i.isEmpty()||u.isEmpty()||i.length()>30||u.length()>20||v.length()>30){status("품목·단위를 확인하세요 (최대 30/20자)");return;}
                String c=corp.getSelectedItem().toString(),g=grade.getSelectedItem().toString();
                if("가락시장 전체".equals(c)||"강서시장 전체".equals(c)){
                    if(editing!=null){status("기존 즐겨찾기 수정 시 개별 법인을 선택하세요. 전체 선택은 새로 추가할 때만 가능합니다.");return;}
                    String[] selected="가락시장 전체".equals(c)?GARAK:GANGSEO;
                    int inserted=0;
                    for(String target:selected){
                        boolean exists=false;
                        for(Favorite other:favorites)if(other.corp.equals(target)&&other.item.equals(i)&&other.unit.equals(u)&&other.grade.equals(g)&&other.variety.equals(v)){exists=true;break;}
                        if(!exists){favorites.add(new Favorite(target,i,u,g,v));inserted++;}
                    }
                    save();renderItems();status(inserted+"개 법인 즐겨찾기 추가됨. 각 항목의 알림을 켜세요. 전체 시장은 5분 내 전 법인 조회가 보장되지 않습니다.");return;
                }
                for(Favorite other:favorites) if(other!=editing&&other.corp.equals(c)&&other.item.equals(i)&&other.unit.equals(u)&&other.grade.equals(g)&&other.variety.equals(v)) {status("이미 등록된 즐겨찾기입니다.");return;}
                Favorite f=new Favorite(c,i,u,g,v);
                if(editing!=null){
                    f.id=editing.id;
                    int index=favorites.indexOf(editing);String oldTopic=editing.topic;
                    // 이전 알림 구독과 서버 등록을 정리한다. 새 조건은 알림 OFF로 시작한다.
                    if(!oldTopic.isEmpty()) {
                        if(editing.enabled) FirebaseMessaging.getInstance().unsubscribeFromTopic(oldTopic)
                            .addOnCompleteListener(t->{if(!t.isSuccessful()) status("기존 알림 구독 해제 실패 · 확인 필요");});
                        enqueueUnwatch(editing);
                        executor.execute(this::drainPendingUnwatches);
                    }
                    if(index>=0) favorites.set(index,f);
                }else favorites.add(f);
                save();renderItems();status("즐겨찾기 저장됨. 해당 항목의 알림 스위치를 켜세요.");
            }).show();
    }
    private void registerAndSubscribe(Favorite f,Runnable completion,boolean refresh){
        executor.execute(()->{
            try{
                if(!drainPendingUnwatches())throw new Exception("해제 대기 중 · 네트워크 연결을 확인하세요");
                String topic=new JSONObject(postJson("/api/watch",favoritePayload(f))).getString("topic");
                runOnUiThread(()-> FirebaseMessaging.getInstance().subscribeToTopic(topic).addOnCompleteListener(task->{
                    if(task.isSuccessful()){
                        f.topic=topic;f.enabled=true;save();if(!refresh)status("알림 ON: "+f.title());
                    }else {
                        enqueueUnwatch(f);
                        executor.execute(this::drainPendingUnwatches);
                        status("Firebase 구독 실패: 네트워크/설정 확인");
                    }
                    renderItems();if(completion!=null)completion.run();
                }));
            }catch(Exception e){status("서버 등록 실패: "+e.getMessage());runOnUiThread(()->{renderItems();if(completion!=null)completion.run();});}
        });
    }
    private void initClientIdentity(){
        clientId=prefs.getString("client_id_v4", "");
        clientSecret=prefs.getString("client_secret_v4", "");
        if(clientId.isEmpty() || clientSecret.length()!=64){
            clientId=UUID.randomUUID().toString();
            byte[] bytes=new byte[32];new SecureRandom().nextBytes(bytes);
            StringBuilder hex=new StringBuilder();
            for(byte b:bytes)hex.append(String.format(java.util.Locale.US,"%02x",b & 0xff));
            clientSecret=hex.toString();
            prefs.edit().putString("client_id_v4",clientId).putString("client_secret_v4",clientSecret).apply();
        }
    }
    private JSONObject favoritePayload(Favorite f)throws Exception{
        JSONObject j=new JSONObject();
        j.put("corp",f.corp);j.put("item",f.item);j.put("unit",f.unit);
        j.put("grade",f.grade);j.put("variety",f.variety);
        j.put("client_id",clientId);j.put("client_secret",clientSecret);
        return j;
    }
    private String postJson(String route,JSONObject data)throws Exception{
        HttpURLConnection conn=(HttpURLConnection)new URL(API+route).openConnection();
        try{
            conn.setConnectTimeout(12000);conn.setReadTimeout(12000);
            conn.setRequestMethod("POST");conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type","application/json; charset=UTF-8");
            try(OutputStream os=conn.getOutputStream()){
                os.write(data.toString().getBytes(StandardCharsets.UTF_8));
            }
            int status=conn.getResponseCode();
            try(BufferedReader r=new BufferedReader(new InputStreamReader(
                    status<400?conn.getInputStream():conn.getErrorStream(),StandardCharsets.UTF_8))){
                StringBuilder b=new StringBuilder();String line;
                while((line=r.readLine())!=null)b.append(line);
                if(status<200 || status>=300)throw new Exception("HTTP "+status+" "+b.toString());
                return b.toString();
            }
        }finally{conn.disconnect();}
    }
    private void enqueueUnwatch(Favorite f){
        try{
            JSONArray q=new JSONArray(prefs.getString("pending_unwatches_v4","[]"));
            q.put(favoritePayload(f));
            prefs.edit().putString("pending_unwatches_v4",q.toString()).apply();
        }catch(Exception e){status("서버 해제 기록 저장 실패");}
    }
    private synchronized boolean drainPendingUnwatches(){
        try{
            JSONArray q=new JSONArray(prefs.getString("pending_unwatches_v4","[]"));
            if(q.length()==0)return true;
            JSONArray rest=new JSONArray();
            boolean succeeded=true;
            for(int i=0;i<q.length();i++){
                JSONObject entry=q.getJSONObject(i);
                try{postJson("/api/unwatch",entry);}
                catch(Exception e){rest.put(entry);succeeded=false;}
            }
            prefs.edit().putString("pending_unwatches_v4",rest.toString()).commit();
            if(!succeeded)status("일부 서버 해제 실패 · 앱 재실행 시 재시도");
            return succeeded;
        }catch(Exception e){status("서버 해제 재시도 실패");return false;}
    }
    private JSONObject testPayload() throws Exception {
        JSONObject obj=new JSONObject();
        obj.put("client_id",clientId);
        obj.put("client_secret",clientSecret);
        return obj;
    }
    private void diagnosticStatus(String message) {
        runOnUiThread(()->{if(testStatus!=null)testStatus.setText(message);});
    }
    private void sendFakeAuction(Button button) {
        if(favorites.stream().noneMatch(f->f.enabled)){
            diagnosticStatus("먼저 즐겨찾기 알림을 하나 이상 ON으로 설정하세요.");
            return;
        }
        button.setEnabled(false);
        diagnosticStatus("휴대폰 Firebase 토큰 읽는 중…");
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task->{
            if(!task.isSuccessful()||task.getResult()==null||task.getResult().isEmpty()){
                diagnosticStatus("Firebase 토큰 읽기 실패: 인터넷/Google Play 서비스를 확인하세요.");
                button.setEnabled(true);return;
            }
            final String token=task.getResult();
            executor.execute(()->{
                try{
                    JSONObject register=testPayload();register.put("fcm_token",token);
                    JSONObject registered=new JSONObject(postJson("/api/test/register",register));
                    if(!registered.optBoolean("ok"))throw new Exception(registered.optString("error","기기 등록 실패"));
                    diagnosticStatus("휴대폰 등록 성공. 테스트 푸시 전송 중…");
                    JSONObject reply=new JSONObject(postJson("/api/test/send",testPayload()));
                    if(!reply.optBoolean("ok"))throw new Exception(reply.optString("error","전송 실패"));
                    diagnosticStatus("Firebase 발송 접수됨. 알림창에서 가짜 경매 알림을 확인한 뒤 아래 '수신 결과 확인'을 눌러주세요.");
                }catch(Exception ex){diagnosticStatus("진단 실패: "+ex.getMessage());}
                finally{runOnUiThread(()->button.setEnabled(true));}
            });
        });
    }
    private void fetchTestStatus(){
        diagnosticStatus("서버의 휴대폰 수신 확인 기록 조회 중…");
        executor.execute(()->{
            try{
                JSONObject reply=new JSONObject(postJson("/api/test/status",testPayload()));
                JSONObject state=reply.optJSONObject("test");
                if(state==null){diagnosticStatus("아직 테스트 전입니다. 위 버튼으로 가짜 경매 알림을 보내세요.");return;}
                boolean sent=state.has("sent_at")&&!state.isNull("sent_at");
                boolean received=state.has("received_at")&&!state.isNull("received_at");
                boolean opened=state.has("opened_at")&&!state.isNull("opened_at");
                String message="Firebase "+(sent?"접수 완료":"미접수")+
                    " / 휴대폰 수신 "+(received?"확인됨":"미확인")+
                    " / 상세 클릭 "+(opened?"확인됨":"미확인");
                String error=state.optString("error","");
                diagnosticStatus(message+(error.isEmpty()?"":" / 오류: "+error));
            }catch(Exception ex){diagnosticStatus("결과 확인 실패: "+ex.getMessage());}
        });
    }
    private void showHistoryFilter(){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(18),0,dp(18),0);
        EditText date=new EditText(this);date.setSingleLine(true);date.setHint("YYYY.MM.DD (비우면 전체)");body.addView(fieldLabel("장일자"));body.addView(date);
        EditText corp=new EditText(this);corp.setSingleLine(true);corp.setHint("한국청과, 강서청과 등");body.addView(fieldLabel("법인 (선택)"));body.addView(corp);
        EditText item=new EditText(this);item.setSingleLine(true);item.setHint("감귤, 당근 등");body.addView(fieldLabel("품목 (선택)"));body.addView(item);
        new AlertDialog.Builder(this).setTitle("서버 경매 알림 발송 내역")
            .setMessage("서버의 Firebase 발송 접수 내역이며 휴대폰에 실제로 뜬 기록과는 다릅니다.")
            .setView(body).setNegativeButton("취소",null)
            .setPositiveButton("조회",(d,w)->queryHistory(date.getText().toString().trim(),
                corp.getText().toString().trim(),item.getText().toString().trim())).show();
    }
    private void queryHistory(String date,String corp,String item){
        status("알림 발송 이력 조회 중…");
        executor.execute(()->{
            try{
                JSONObject req=testPayload();req.put("date",date);req.put("corp",corp);req.put("item",item);
                JSONObject out=new JSONObject(postJson("/api/history",req));
                JSONArray rows=out.optJSONArray("results");if(rows==null)throw new Exception("조회 결과 오류");
                String[] labels=new String[rows.length()];
                for(int k=0;k<rows.length();k++){
                    JSONObject x=rows.getJSONObject(k);
                    labels[k]=x.optString("market_date")+" · "+x.optString("corp")+" · "+x.optString("item")+
                        " "+x.optString("unit")+" "+x.optString("grade")+
                        "\n"+("sent".equals(x.optString("state"))?"Firebase 접수":"서버 "+x.optString("state"))+
                        ("reconstructed_from_current_subscription".equals(x.optString("association"))?" · 과거 대상 추정":"");
                }
                runOnUiThread(()->{
                    status(rows.length()+"건 조회됨 (서버 접수 내역, 실제 수신과 다름)");
                    new AlertDialog.Builder(this).setTitle("과거 경매 알림 · "+rows.length()+"건")
                        .setItems(labels,(d,index)->{
                            JSONObject x=rows.optJSONObject(index);
                            if(x!=null)openTrustedDetails(x.optString("detail_url"));
                        }).setPositiveButton("닫기",null).show();
                });
            }catch(Exception e){status("과거 알림 조회 실패: "+e.getMessage());}
        });
    }
    private void showUnitDiagnostics(){
        status("현재 장일자 kg 일치 건수 확인 중…");
        executor.execute(()->{
            try{
                JSONObject out=new JSONObject(postJson("/api/diagnose/units",testPayload()));
                JSONArray a=out.optJSONArray("diagnostics");if(a==null)throw new Exception("진단 데이터 오류");
                StringBuilder report=new StringBuilder();
                for(int i=0;i<a.length();i++){
                    JSONObject x=a.getJSONObject(i);
                    report.append(x.optString("corp")).append(" · ").append(x.optString("item"))
                    .append(" · ").append(x.optString("requested_unit"))
                    .append(" → 저장된 일치 ").append(x.optInt("matched_saved_rows")).append("건")
                    .append("\n원본 단위 표기: ").append(x.optJSONArray("available_raw_units"))
                    .append("\n진단: ").append(x.optString("note"))
                    .append("\n\n");
                }
                runOnUiThread(()->new AlertDialog.Builder(this).setTitle("kg 규격 매칭 진단")
                    .setMessage(report.length()>0?report.toString():"현재 ON인 즐겨찾기 등록 없음")
                    .setPositiveButton("닫기",null).show());
            }catch(Exception e){status("규격 진단 실패: "+e.getMessage());}
        });
    }
    private void askAdminKey(){
        EditText key=new EditText(this);key.setSingleLine(true);key.setHint("Cloudflare ADMIN_API_KEY");
        key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle("서버 구독 관리자 인증")
            .setMessage("Cloudflare Worker에 등록한 ADMIN_API_KEY를 입력하세요. 이 값은 휴대폰에 저장하지 않습니다.")
            .setView(key).setNegativeButton("취소",null)
            .setPositiveButton("계속",(d,w)->{
                String k=key.getText().toString();key.setText("");
                if(k.length()<20){status("관리자 키 길이를 확인하세요.");return;}
                showAdminActions(k);
            }).show();
    }
    private JSONObject adminPayload(String key)throws Exception{
        JSONObject j=testPayload();j.put("admin_key",key);return j;
    }
    private void showAdminActions(String key){
        String[] actions={"서버 구독 전체 목록 확인 / 개별 선택 삭제",
            "현재 휴대폰 등록만 남기고 서버 정리", "전체 서버 구독 초기화"};
        new AlertDialog.Builder(this).setTitle("서버 구독 관리")
            .setItems(actions,(d,which)->{
                if(which==0)listServerSubscriptions(key);
                else if(which==1)new AlertDialog.Builder(this)
                    .setTitle("현재 휴대폰만 남길까요?")
                    .setMessage("다른 앱 설치본의 서버 구독만 삭제합니다. 기존 경락가격과 과거 발송 이력은 보존합니다.")
                    .setNegativeButton("취소",null)
                    .setPositiveButton("현재 휴대폰만 유지",(dialog,index)->adminAction(key,"/api/admin/retain-current",null)).show();
                else confirmReset(key);
            }).setNegativeButton("닫기",null).show();
    }
    private void listServerSubscriptions(String key){
        status("서버 등록 목록 확인 중…");
        executor.execute(()->{
            try{
                JSONObject out=new JSONObject(postJson("/api/admin/list",adminPayload(key)));
                JSONArray rows=out.optJSONArray("subscriptions");if(rows==null)throw new Exception("목록 없음");
                String[] lines=new String[rows.length()];
                for(int i=0;i<rows.length();i++){
                    JSONObject r=rows.getJSONObject(i);
                    boolean me=clientId.equals(r.optString("client_id"));
                    String id=r.optString("client_id");
                    lines[i]=(me?"[현재 휴대폰] ":"[과거/다른 등록] ")+
                        (id.length()>8?id.substring(0,8):id)+" · "+r.optString("corp")+
                        " · "+r.optString("item")+" · "+r.optString("unit")+" · "+r.optString("grade");
                }
                runOnUiThread(()->new AlertDialog.Builder(this).setTitle("서버 구독 "+rows.length()+"건 · 탭하여 삭제")
                    .setItems(lines,(d,index)->{
                        JSONObject entry=rows.optJSONObject(index);if(entry==null)return;
                        new AlertDialog.Builder(this).setTitle("이 등록만 서버에서 삭제할까요?")
                            .setMessage(lines[index]+"\n가격·이력 데이터는 삭제하지 않습니다.")
                            .setNegativeButton("취소",null).setPositiveButton("선택 삭제",(dd,idx)->{
                                try{
                                    JSONObject req=new JSONObject();req.put("client_id",entry.getString("client_id"));
                                    req.put("watch_id",entry.getString("watch_id"));
                                    adminAction(key,"/api/admin/remove",req);
                                }catch(Exception ex){status("삭제 요청 오류: "+ex.getMessage());}
                            }).show();
                    }).setPositiveButton("닫기",null).show());
            }catch(Exception e){status("관리자 목록 오류: "+e.getMessage());}
        });
    }
    private void confirmReset(String key){
        new AlertDialog.Builder(this).setTitle("전체 서버 구독 초기화")
            .setMessage("경고: 모든 휴대폰의 서버 구독을 삭제합니다. 과거 경락가격과 서버 발송 이력은 보존됩니다. 초기화 후 현재 휴대폰의 ON 즐겨찾기도 '다시 등록'해야 알림이 옵니다.")
            .setNegativeButton("취소",null)
            .setPositiveButton("전체 구독 삭제",(d,w)->{
                try{
                    JSONObject extra=new JSONObject();extra.put("confirm","DELETE ALL SUBSCRIPTIONS");
                    adminAction(key,"/api/admin/reset",extra);
                }catch(Exception e){status(e.getMessage());}
            }).show();
    }
    private void adminAction(String key,String route,JSONObject extra){
        status("관리자 요청 처리 중…");
        executor.execute(()->{
            try{
                JSONObject request=adminPayload(key);
                if(extra!=null){java.util.Iterator<String> it=extra.keys();while(it.hasNext()){
                    String k=it.next();request.put(k,extra.get(k));
                }}
                JSONObject reply=new JSONObject(postJson(route,request));
                status("서버 처리 완료: "+reply.toString());
            }catch(Exception e){status("서버 관리자 작업 실패: "+e.getMessage());}
        });
    }

    private void openNotificationLink(Intent intent){
        String testId=intent.getStringExtra("test_id");
        if(testId!=null && testId.matches("[0-9a-f]{64}")) {
            TestReporter.ack(this,testId,"opened");
            status("가짜 경매 알림 클릭 확인 · 상세화면 열기");
        }
        String link=intent.getStringExtra("url");
        if(link==null || link.isEmpty()){
            // Older notifications can still use the generic Garak website.
            openSite();return;
        }
        openTrustedDetails(link);
    }
    private void openTrustedDetails(String link){
        try{
            Uri uri=Uri.parse(link);
            if(!"https".equalsIgnoreCase(uri.getScheme()) ||
               !"garak-auction-alert.mapohyunkyu.workers.dev".equalsIgnoreCase(uri.getHost()) ||
               !("/detail".equals(uri.getPath()) || "/watch".equals(uri.getPath()))){
                status("알 수 없는 상세 주소 · 원본 사이트로 이동");openSite();return;
            }
            Intent detail=new Intent(this,DetailActivity.class);
            detail.putExtra("url",uri.toString());
            startActivity(detail);
        }catch(Exception e){status("상세화면 열기 실패");openSite();}
    }
    private void openSite(){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(SITE)));}
    private void openGangseoSite(){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(SITE_GANGSEO)));}
    private void createNotificationChannel(){
        if(Build.VERSION.SDK_INT>=26){NotificationManager manager=getSystemService(NotificationManager.class);
            NotificationChannel channel=new NotificationChannel("auction","경매결과 알림",NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("즐겨찾기 경매 결과 알림");manager.createNotificationChannel(channel);}
    }
    @Override protected void onDestroy(){super.onDestroy();executor.shutdown();}
}
