package kr.garak.auctionalert;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.UUID;
import java.security.SecureRandom;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String API = "https://garak-auction-alert.mapohyunkyu.workers.dev";
    private static final String SITE = "https://temp.garak.co.kr/price/resultAuctionList.do?market_cd=1";
    private static final String[] CORPS = {"한국청과", "대아청과"};
    private static final String[] GRADES = {"특", "상", "중", "등외", "전체"};
    private static final String[] ITEMS = {
        "바나나", "사과", "배", "감귤", "오렌지", "포도", "샤인머스캣", "복숭아", "자두",
        "체리", "키위", "참다래", "딸기", "수박", "참외", "토마토", "방울토마토",
        "멜론", "레몬", "망고", "파인애플", "블루베리", "단감", "대봉", "떫은감",
        "당근", "양배추", "고구마", "감자", "표고", "오이", "양파", "쪽파", "초롱무",
        "상추", "배추", "무", "마늘", "깻잎", "부추", "시금치", "브로콜리", "파프리카"
    };
    private static final String[] UNITS = {
        "전체", "500g", "1kg", "2kg", "2.5kg", "3kg", "4kg", "5kg", "6kg", "7kg",
        "7.5kg", "8kg", "9kg", "10kg", "11kg", "12kg", "13kg", "14kg", "15kg",
        "16kg", "17kg", "18kg", "20kg", "상자", "박스", "그물망"
    };
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final ArrayList<Favorite> favorites=new ArrayList<>();
    private LinearLayout itemsView;
    private TextView status;
    private SharedPreferences prefs;
    private String clientId, clientSecret;

    static class Favorite {
        String id,corp,item,unit,grade,variety,topic="";
        boolean enabled=false;
        Favorite(String c,String i,String u,String g,String v) {
            id=UUID.randomUUID().toString();corp=c;item=i;unit=u;grade=g;variety=v;
        }
        String title(){return corp+" · "+item+(variety.isEmpty()?"":" ("+variety+")")+" · "+unit+" · "+grade;}
        JSONObject json(){
            JSONObject j=new JSONObject();
            try {j.put("id",id);j.put("corp",corp);j.put("item",item);j.put("unit",unit);j.put("grade",grade);j.put("variety",variety);j.put("topic",topic);j.put("enabled",enabled);}catch(Exception ignored){}
            return j;
        }
        static Favorite from(JSONObject j){
            Favorite f=new Favorite(j.optString("corp","한국청과"),j.optString("item","당근"),j.optString("unit","20kg"),j.optString("grade","특"),j.optString("variety",""));
            f.id=j.optString("id",f.id);f.topic=j.optString("topic","");f.enabled=j.optBoolean("enabled",false);return f;
        }
    }
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("favorites_v2",MODE_PRIVATE);
        createNotificationChannel();
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},123);
        initClientIdentity();load();render();
        executor.execute(this::drainPendingUnwatches);
        // 기존 1차 시범 앱의 고정 토픽 구독은 취소한다.
        FirebaseMessaging.getInstance().unsubscribeFromTopic("garak_hankook_carrot20_special");
        FirebaseMessaging.getInstance().unsubscribeFromTopic("garak_daea_carrot20_special");
        for(Favorite f:new ArrayList<>(favorites))if(f.enabled)registerAndSubscribe(f,null,true);
        if(getIntent()!=null&&"kr.garak.auctionalert.OPEN_GARAK".equals(getIntent().getAction()))openNotificationLink(getIntent());
    }
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);if("kr.garak.auctionalert.OPEN_GARAK".equals(i.getAction()))openNotificationLink(i);}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView label(String s,int sp,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);return t;}
    private void status(String s){runOnUiThread(()->{if(status!=null)status.setText(s);});}
    private void load(){
        favorites.clear();
        try {JSONArray a=new JSONArray(prefs.getString("list","[]"));for(int n=0;n<a.length();n++)favorites.add(Favorite.from(a.getJSONObject(n)));}
        catch(Exception e){/* 손상된 즐겨찾기 데이터는 앱이 중단되지 않게 한다. */}
    }
    private void save(){JSONArray a=new JSONArray();for(Favorite f:favorites)a.put(f.json());prefs.edit().putString("list",a.toString()).apply();}
    private void render(){
        ScrollView scroll=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(23),dp(18),dp(24));root.setBackgroundColor(Color.WHITE);
        scroll.addView(root);
        TextView heading=label("가락시장 경매 알림",24,0xff171717);root.addView(heading);
        TextView subtitle=label("한국청과·대아청과 | 원하는 품목을 즐겨찾기",14,0xff666666);subtitle.setPadding(0,dp(8),0,dp(18));root.addView(subtitle);
        Button add=new Button(this);add.setText("+ 즐겨찾기 추가");add.setOnClickListener(v->showEditor(null));root.addView(add);
        itemsView=new LinearLayout(this);itemsView.setOrientation(LinearLayout.VERTICAL);root.addView(itemsView);
        Button site=new Button(this);site.setText("가락시장 경매결과 홈페이지 열기");site.setOnClickListener(v->openSite());root.addView(site);
        status=label("알림은 즐겨찾기를 켠 품목에만 설정됩니다.",13,0xff555555);status.setPadding(0,dp(13),0,dp(7));root.addView(status);
        TextView hint=label("※ 서버와 Firebase 연결이 완료되어야 실제 푸시가 옵니다.\n※ 원본 OZ 보고서 뷰어는 모바일 브라우저에서 오류가 날 수 있습니다.",12,0xff777777);root.addView(hint);
        setContentView(scroll);renderItems();
    }
    private void renderItems(){
        if(itemsView==null)return;itemsView.removeAllViews();
        if(favorites.isEmpty()){
            TextView empty=label("등록한 즐겨찾기가 없어요.\n위 버튼을 눌러 품목·단위·등급을 등록하세요.",14,0xff666666);
            empty.setPadding(dp(6),dp(22),dp(6),dp(22));itemsView.addView(empty);return;
        }
        for(Favorite f:new ArrayList<>(favorites)){
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(10),dp(12),dp(10),dp(10));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(8),0,dp(8));itemsView.addView(card,lp);
            card.setBackgroundColor(0xfff1f4f7);
            TextView name=label(f.title(),16,0xff151515);card.addView(name);
            Switch sw=new Switch(this);sw.setText(f.enabled?"알림 ON":"알림 OFF");sw.setChecked(f.enabled);
            sw.setOnCheckedChangeListener((button,on)->{
                sw.setEnabled(false);
                if(on){
                    registerAndSubscribe(f,()->{sw.setEnabled(true);renderItems();},false);
                }else{
                    if(f.topic.isEmpty()) {
                        f.enabled=false;save();sw.setEnabled(true);renderItems();return;
                    }
                    FirebaseMessaging.getInstance().unsubscribeFromTopic(f.topic).addOnCompleteListener(task->{
                        sw.setEnabled(true);
                        if(task.isSuccessful()) {
                            enqueueUnwatch(f);
                            f.enabled=false;f.topic="";
                            save();renderItems();
                            status("알림 OFF · 서버 해제 요청 중");
                            executor.execute(this::drainPendingUnwatches);
                        }else{
                            status("Firebase 구독 해제 실패 · 다시 시도해 주세요");
                            renderItems();
                        }
                    });
                }
            });card.addView(sw);
            LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
            Button edit=new Button(this);edit.setText("수정");edit.setOnClickListener(v->showEditor(f));actions.addView(edit,new LinearLayout.LayoutParams(0,-2,1));
            Button remove=new Button(this);remove.setText("삭제");remove.setOnClickListener(v->new AlertDialog.Builder(this)
                .setMessage("이 즐겨찾기를 삭제할까요?")
                .setNegativeButton("취소",null).setPositiveButton("삭제",(d,w)->{
                    Runnable finish=()->{
                        if(!f.topic.isEmpty())enqueueUnwatch(f);
                        favorites.remove(f);save();renderItems();
                        status("즐겨찾기 삭제 · 서버 해제 요청 중");
                        executor.execute(this::drainPendingUnwatches);
                    };
                    if(f.enabled && !f.topic.isEmpty()){
                        FirebaseMessaging.getInstance().unsubscribeFromTopic(f.topic)
                            .addOnCompleteListener(task->{
                                if(task.isSuccessful())finish.run();
                                else status("구독 해제 실패 · 삭제하지 않았어요. 다시 시도해 주세요");
                            });
                    }else finish.run();
                }).show());actions.addView(remove,new LinearLayout.LayoutParams(0,-2,1));
            card.addView(actions);
            if(!f.topic.isEmpty()){
                Button details=new Button(this);details.setText("가격순 상세 보기");
                details.setOnClickListener(v->{
                    String link=API+"/watch?topic="+Uri.encode(f.topic);
                    openTrustedDetails(link);
                });
                card.addView(details);
            }
        }
    }
    private TextView fieldLabel(String text){TextView t=label(text,14,0xff333333);t.setPadding(0,dp(12),0,dp(3));return t;}
    private void showEditor(Favorite editing){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(18),0,dp(18),0);
        body.addView(fieldLabel("법인"));Spinner corp=new Spinner(this);corp.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,CORPS));
        if(editing!=null)corp.setSelection(editing.corp.equals("대아청과")?1:0);body.addView(corp);
        body.addView(fieldLabel("품목 (과일·채소 검색 또는 직접 입력)"));AutoCompleteTextView item=new AutoCompleteTextView(this);
        item.setSingleLine(true);item.setThreshold(1);item.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,ITEMS));
        item.setHint("예: 바나나, 사과, 당근");if(editing!=null)item.setText(editing.item);body.addView(item);
        body.addView(fieldLabel("품종 / 세부규격 (선택)"));EditText variety=new EditText(this);variety.setSingleLine(true);
        variety.setHint("예: 세척, 흙, 백다다기");if(editing!=null)variety.setText(editing.variety);body.addView(variety);
        body.addView(fieldLabel("kg / 단위 · 전체 선택 가능"));
        AutoCompleteTextView unit=new AutoCompleteTextView(this);
        unit.setSingleLine(true);unit.setThreshold(0);
        unit.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,UNITS));
        unit.setHint("전체 또는 5kg, 13kg 등 실제 규격");
        unit.setText(editing==null?"전체":editing.unit, false);
        unit.setOnClickListener(v->unit.showDropDown());
        body.addView(unit);
        TextView unitNote=label("전체 선택 시 모든 kg를 검색하고 가격은 규격별로 구분해 알립니다. 규격은 직접 입력도 가능합니다.",12,0xff666666);
        body.addView(unitNote);
        body.addView(fieldLabel("등급"));Spinner grade=new Spinner(this);grade.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,GRADES));
        if(editing!=null){for(int n=0;n<GRADES.length;n++)if(GRADES[n].equals(editing.grade))grade.setSelection(n);}
        else grade.setSelection(GRADES.length-1);
        body.addView(grade);
        ScrollView sc=new ScrollView(this);sc.addView(body);
        new AlertDialog.Builder(this).setTitle(editing==null?"즐겨찾기 추가":"즐겨찾기 수정")
            .setView(sc).setNegativeButton("취소",null)
            .setPositiveButton("저장",(d,w)->{
                String i=item.getText().toString().trim(),u=unit.getText().toString().trim(),v=variety.getText().toString().trim();
                if(i.isEmpty()||u.isEmpty()||i.length()>30||u.length()>20||v.length()>30){status("품목·단위를 확인하세요 (최대 30/20자)");return;}
                String c=corp.getSelectedItem().toString(),g=grade.getSelectedItem().toString();
                for(Favorite other:favorites) if(other!=editing&&other.corp.equals(c)&&other.item.equals(i)&&other.unit.equals(u)&&other.grade.equals(g)&&other.variety.equals(v)) {status("이미 등록된 즐겨찾기입니다.");return;}
                Favorite f=new Favorite(c,i,u,g,v);
                if(editing!=null){
                    f.id=editing.id;
                    int index=favorites.indexOf(editing);String oldTopic=editing.topic;
                    // 이전 알림 구독과 서버 등록을 정리한다. 새 조건은 알림 OFF로 시작한다.
                    if(!oldTopic.isEmpty()) {
                        if(editing.enabled) FirebaseMessaging.getInstance().unsubscribeFromTopic(oldTopic)
                            .addOnCompleteListener(t->{if(!t.isSuccessful()) status("기존 알림 구독 해제 실패 · 확인 필요");});
                        enqueueUnwatch(editing);
                        executor.execute(this::drainPendingUnwatches);
                    }
                    if(index>=0) favorites.set(index,f);
                }else favorites.add(f);
                save();renderItems();status("즐겨찾기 저장됨. 해당 항목의 알림 스위치를 켜세요.");
            }).show();
    }
    private void registerAndSubscribe(Favorite f,Runnable completion,boolean refresh){
        executor.execute(()->{
            try{
                if(!drainPendingUnwatches())throw new Exception("해제 대기 중 · 네트워크 연결을 확인하세요");
                String topic=new JSONObject(postJson("/api/watch",favoritePayload(f))).getString("topic");
                runOnUiThread(()-> FirebaseMessaging.getInstance().subscribeToTopic(topic).addOnCompleteListener(task->{
                    if(task.isSuccessful()){
                        f.topic=topic;f.enabled=true;save();if(!refresh)status("알림 ON: "+f.title());
                    }else {
                        enqueueUnwatch(f);
                        executor.execute(this::drainPendingUnwatches);
                        status("Firebase 구독 실패: 네트워크/설정 확인");
                    }
                    renderItems();if(completion!=null)completion.run();
                }));
            }catch(Exception e){status("서버 등록 실패: "+e.getMessage());runOnUiThread(()->{renderItems();if(completion!=null)completion.run();});}
        });
    }
    private void initClientIdentity(){
        clientId=prefs.getString("client_id_v4", "");
        clientSecret=prefs.getString("client_secret_v4", "");
        if(clientId.isEmpty() || clientSecret.length()!=64){
            clientId=UUID.randomUUID().toString();
            byte[] bytes=new byte[32];new SecureRandom().nextBytes(bytes);
            StringBuilder hex=new StringBuilder();
            for(byte b:bytes)hex.append(String.format(java.util.Locale.US,"%02x",b & 0xff));
            clientSecret=hex.toString();
            prefs.edit().putString("client_id_v4",clientId).putString("client_secret_v4",clientSecret).apply();
        }
    }
    private JSONObject favoritePayload(Favorite f)throws Exception{
        JSONObject j=new JSONObject();
        j.put("corp",f.corp);j.put("item",f.item);j.put("unit",f.unit);
        j.put("grade",f.grade);j.put("variety",f.variety);
        j.put("client_id",clientId);j.put("client_secret",clientSecret);
        return j;
    }
    private String postJson(String route,JSONObject data)throws Exception{
        HttpURLConnection conn=(HttpURLConnection)new URL(API+route).openConnection();
        try{
            conn.setConnectTimeout(12000);conn.setReadTimeout(12000);
            conn.setRequestMethod("POST");conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type","application/json; charset=UTF-8");
            try(OutputStream os=conn.getOutputStream()){
                os.write(data.toString().getBytes(StandardCharsets.UTF_8));
            }
            int status=conn.getResponseCode();
            try(BufferedReader r=new BufferedReader(new InputStreamReader(
                    status<400?conn.getInputStream():conn.getErrorStream(),StandardCharsets.UTF_8))){
                StringBuilder b=new StringBuilder();String line;
                while((line=r.readLine())!=null)b.append(line);
                if(status<200 || status>=300)throw new Exception("HTTP "+status+" "+b.toString());
                return b.toString();
            }
        }finally{conn.disconnect();}
    }
    private void enqueueUnwatch(Favorite f){
        try{
            JSONArray q=new JSONArray(prefs.getString("pending_unwatches_v4","[]"));
            q.put(favoritePayload(f));
            prefs.edit().putString("pending_unwatches_v4",q.toString()).apply();
        }catch(Exception e){status("서버 해제 기록 저장 실패");}
    }
    private synchronized boolean drainPendingUnwatches(){
        try{
            JSONArray q=new JSONArray(prefs.getString("pending_unwatches_v4","[]"));
            if(q.length()==0)return true;
            JSONArray rest=new JSONArray();
            boolean succeeded=true;
            for(int i=0;i<q.length();i++){
                JSONObject entry=q.getJSONObject(i);
                try{postJson("/api/unwatch",entry);}
                catch(Exception e){rest.put(entry);succeeded=false;}
            }
            prefs.edit().putString("pending_unwatches_v4",rest.toString()).commit();
            if(!succeeded)status("일부 서버 해제 실패 · 앱 재실행 시 재시도");
            return succeeded;
        }catch(Exception e){status("서버 해제 재시도 실패");return false;}
    }
    private void openNotificationLink(Intent intent){
        String link=intent.getStringExtra("url");
        if(link==null || link.isEmpty()){
            // Older notifications can still use the generic Garak website.
            openSite();return;
        }
        openTrustedDetails(link);
    }
    private void openTrustedDetails(String link){
        try{
            Uri uri=Uri.parse(link);
            if(!"https".equalsIgnoreCase(uri.getScheme()) ||
               !"garak-auction-alert.mapohyunkyu.workers.dev".equalsIgnoreCase(uri.getHost()) ||
               !("/detail".equals(uri.getPath()) || "/watch".equals(uri.getPath()))){
                status("알 수 없는 상세 주소 · 원본 사이트로 이동");openSite();return;
            }
            Intent detail=new Intent(this,DetailActivity.class);
            detail.putExtra("url",uri.toString());
            startActivity(detail);
        }catch(Exception e){status("상세화면 열기 실패");openSite();}
    }
    private void openSite(){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(SITE)));}
    private void createNotificationChannel(){
        if(Build.VERSION.SDK_INT>=26){NotificationManager manager=getSystemService(NotificationManager.class);
            NotificationChannel channel=new NotificationChannel("auction","경매결과 알림",NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("즐겨찾기 경매 결과 알림");manager.createNotificationChannel(channel);}
    }
    @Override protected void onDestroy(){super.onDestroy();executor.shutdown();}
}
