package kr.garak.auctionalert;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String API = "https://garak-auction-alert.mapohyunkyu.workers.dev";
    private static final String SITE = "https://temp.garak.co.kr/price/resultAuctionList.do?market_cd=1";
    private static final String[] CORPS = {"한국청과", "대아청과"};
    private static final String[] GRADES = {"특", "상", "중", "등외", "전체"};
    private static final String[] ITEMS = {"당근", "양배추", "고구마", "감자", "표고", "오이", "양파", "쪽파", "초롱무", "상추", "배추", "무"};
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final ArrayList<Favorite> favorites=new ArrayList<>();
    private LinearLayout itemsView;
    private TextView status;
    private SharedPreferences prefs;

    static class Favorite {
        String id,corp,item,unit,grade,variety,topic="";
        boolean enabled=false;
        Favorite(String c,String i,String u,String g,String v) {
            id=UUID.randomUUID().toString();corp=c;item=i;unit=u;grade=g;variety=v;
        }
        String title(){return corp+" · "+item+(variety.isEmpty()?"":" ("+variety+")")+" · "+unit+" · "+grade;}
        JSONObject json(){
            JSONObject j=new JSONObject();
            try {j.put("id",id);j.put("corp",corp);j.put("item",item);j.put("unit",unit);j.put("grade",grade);j.put("variety",variety);j.put("topic",topic);j.put("enabled",enabled);}catch(Exception ignored){}
            return j;
        }
        static Favorite from(JSONObject j){
            Favorite f=new Favorite(j.optString("corp","한국청과"),j.optString("item","당근"),j.optString("unit","20kg"),j.optString("grade","특"),j.optString("variety",""));
            f.id=j.optString("id",f.id);f.topic=j.optString("topic","");f.enabled=j.optBoolean("enabled",false);return f;
        }
    }
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("favorites_v2",MODE_PRIVATE);
        createNotificationChannel();
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},123);
        load();render();
        // 기존 1차 시범 앱의 고정 토픽 구독은 취소한다.
        FirebaseMessaging.getInstance().unsubscribeFromTopic("garak_hankook_carrot20_special");
        FirebaseMessaging.getInstance().unsubscribeFromTopic("garak_daea_carrot20_special");
        for(Favorite f:new ArrayList<>(favorites))if(f.enabled)registerAndSubscribe(f,null,true);
        if(getIntent()!=null&&"kr.garak.auctionalert.OPEN_GARAK".equals(getIntent().getAction()))openSite();
    }
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);if("kr.garak.auctionalert.OPEN_GARAK".equals(i.getAction()))openSite();}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView label(String s,int sp,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);return t;}
    private void status(String s){runOnUiThread(()->{if(status!=null)status.setText(s);});}
    private void load(){
        favorites.clear();
        try {JSONArray a=new JSONArray(prefs.getString("list","[]"));for(int n=0;n<a.length();n++)favorites.add(Favorite.from(a.getJSONObject(n)));}
        catch(Exception e){/* 손상된 즐겨찾기 데이터는 앱이 중단되지 않게 한다. */}
    }
    private void save(){JSONArray a=new JSONArray();for(Favorite f:favorites)a.put(f.json());prefs.edit().putString("list",a.toString()).apply();}
    private void render(){
        ScrollView scroll=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(23),dp(18),dp(24));root.setBackgroundColor(Color.WHITE);
        scroll.addView(root);
        TextView heading=label("가락시장 경매 알림",24,0xff171717);root.addView(heading);
        TextView subtitle=label("한국청과·대아청과 | 원하는 품목을 즐겨찾기",14,0xff666666);subtitle.setPadding(0,dp(8),0,dp(18));root.addView(subtitle);
        Button add=new Button(this);add.setText("+ 즐겨찾기 추가");add.setOnClickListener(v->showEditor(null));root.addView(add);
        itemsView=new LinearLayout(this);itemsView.setOrientation(LinearLayout.VERTICAL);root.addView(itemsView);
        Button site=new Button(this);site.setText("가락시장 경매결과 홈페이지 열기");site.setOnClickListener(v->openSite());root.addView(site);
        status=label("알림은 즐겨찾기를 켠 품목에만 설정됩니다.",13,0xff555555);status.setPadding(0,dp(13),0,dp(7));root.addView(status);
        TextView hint=label("※ 서버와 Firebase 연결이 완료되어야 실제 푸시가 옵니다.\n※ 원본 OZ 보고서 뷰어는 모바일 브라우저에서 오류가 날 수 있습니다.",12,0xff777777);root.addView(hint);
        setContentView(scroll);renderItems();
    }
    private void renderItems(){
        if(itemsView==null)return;itemsView.removeAllViews();
        if(favorites.isEmpty()){
            TextView empty=label("등록한 즐겨찾기가 없어요.\n위 버튼을 눌러 품목·단위·등급을 등록하세요.",14,0xff666666);
            empty.setPadding(dp(6),dp(22),dp(6),dp(22));itemsView.addView(empty);return;
        }
        for(Favorite f:new ArrayList<>(favorites)){
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(10),dp(12),dp(10),dp(10));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(8),0,dp(8));itemsView.addView(card,lp);
            card.setBackgroundColor(0xfff1f4f7);
            TextView name=label(f.title(),16,0xff151515);card.addView(name);
            Switch sw=new Switch(this);sw.setText(f.enabled?"알림 ON":"알림 OFF");sw.setChecked(f.enabled);
            sw.setOnCheckedChangeListener((button,on)->{
                sw.setEnabled(false);
                if(on){
                    registerAndSubscribe(f,()->{sw.setEnabled(true);renderItems();},false);
                }else{
                    if(f.topic.isEmpty()) {f.enabled=false;save();renderItems();return;}
                    FirebaseMessaging.getInstance().unsubscribeFromTopic(f.topic).addOnCompleteListener(task->{
                        sw.setEnabled(true);
                        if(task.isSuccessful()){f.enabled=false;save();status("알림 OFF: "+f.title());}
                        else status("구독 해제 실패: 네트워크 연결 확인");
                        renderItems();
                    });
                }
            });card.addView(sw);
            LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
            Button edit=new Button(this);edit.setText("수정");edit.setOnClickListener(v->showEditor(f));actions.addView(edit,new LinearLayout.LayoutParams(0,-2,1));
            Button remove=new Button(this);remove.setText("삭제");remove.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("이 즐겨찾기를 삭제할까요?")
                .setNegativeButton("취소",null).setPositiveButton("삭제",(d,w)->{
                    String oldTopic=f.topic;favorites.remove(f);save();renderItems();
                    if(f.enabled&&!oldTopic.isEmpty()) FirebaseMessaging.getInstance().unsubscribeFromTopic(oldTopic);
                    status("즐겨찾기 삭제됨");
                }).show());actions.addView(remove,new LinearLayout.LayoutParams(0,-2,1));
            card.addView(actions);
        }
    }
    private TextView fieldLabel(String text){TextView t=label(text,14,0xff333333);t.setPadding(0,dp(12),0,dp(3));return t;}
    private void showEditor(Favorite editing){
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(18),0,dp(18),0);
        body.addView(fieldLabel("법인"));Spinner corp=new Spinner(this);corp.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,CORPS));
        if(editing!=null)corp.setSelection(editing.corp.equals("대아청과")?1:0);body.addView(corp);
        body.addView(fieldLabel("품목 (직접 입력 가능)"));AutoCompleteTextView item=new AutoCompleteTextView(this);
        item.setSingleLine(true);item.setThreshold(1);item.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,ITEMS));
        item.setHint("예: 당근, 표고, 양배추");if(editing!=null)item.setText(editing.item);body.addView(item);
        body.addView(fieldLabel("품종 / 세부규격 (선택)"));EditText variety=new EditText(this);variety.setSingleLine(true);
        variety.setHint("예: 세척, 흙, 백다다기");if(editing!=null)variety.setText(editing.variety);body.addView(variety);
        body.addView(fieldLabel("단위"));EditText unit=new EditText(this);unit.setSingleLine(true);unit.setHint("예: 20kg, 10kg, 8kg");
        unit.setText(editing==null?"20kg":editing.unit);body.addView(unit);
        body.addView(fieldLabel("등급"));Spinner grade=new Spinner(this);grade.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,GRADES));
        if(editing!=null)for(int n=0;n<GRADES.length;n++)if(GRADES[n].equals(editing.grade))grade.setSelection(n);body.addView(grade);
        ScrollView sc=new ScrollView(this);sc.addView(body);
        new AlertDialog.Builder(this).setTitle(editing==null?"즐겨찾기 추가":"즐겨찾기 수정")
            .setView(sc).setNegativeButton("취소",null)
            .setPositiveButton("저장",(d,w)->{
                String i=item.getText().toString().trim(),u=unit.getText().toString().trim(),v=variety.getText().toString().trim();
                if(i.isEmpty()||u.isEmpty()||i.length()>30||u.length()>20||v.length()>30){status("품목·단위를 확인하세요 (최대 30/20자)");return;}
                String c=corp.getSelectedItem().toString(),g=grade.getSelectedItem().toString();
                for(Favorite other:favorites) if(other!=editing&&other.corp.equals(c)&&other.item.equals(i)&&other.unit.equals(u)&&other.grade.equals(g)&&other.variety.equals(v)) {status("이미 등록된 즐겨찾기입니다.");return;}
                Favorite f=new Favorite(c,i,u,g,v);
                if(editing!=null){
                    f.id=editing.id;
                    int index=favorites.indexOf(editing);String oldTopic=editing.topic;
                    // 수정시에는 이전 토픽 구독을 해제한 뒤 새 조건을 별도로 켜야 한다.
                    if(editing.enabled&&!oldTopic.isEmpty())FirebaseMessaging.getInstance().unsubscribeFromTopic(oldTopic);
                    if(index>=0) favorites.set(index,f);
                }else favorites.add(f);
                save();renderItems();status("즐겨찾기 저장됨. 해당 항목의 알림 스위치를 켜세요.");
            }).show();
    }
    private void registerAndSubscribe(Favorite f,Runnable completion,boolean refresh){
        executor.execute(()->{
            try{
                JSONObject input=new JSONObject();input.put("corp",f.corp);input.put("item",f.item);input.put("unit",f.unit);
                input.put("grade",f.grade);input.put("variety",f.variety);
                HttpURLConnection conn=(HttpURLConnection)new URL(API+"/api/watch").openConnection();
                conn.setConnectTimeout(12000);conn.setReadTimeout(12000);conn.setRequestMethod("POST");conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type","application/json; charset=UTF-8");
                try(OutputStream os=conn.getOutputStream()){os.write(input.toString().getBytes(StandardCharsets.UTF_8));}
                int http=conn.getResponseCode();
                BufferedReader reader=new BufferedReader(new InputStreamReader(http<400?conn.getInputStream():conn.getErrorStream(),StandardCharsets.UTF_8));
                StringBuilder text=new StringBuilder();String line;while((line=reader.readLine())!=null)text.append(line);reader.close();conn.disconnect();
                if(http<200||http>=300)throw new Exception("서버 HTTP "+http+" "+text.substring(0,Math.min(text.length(),80)));
                String topic=new JSONObject(text.toString()).getString("topic");
                runOnUiThread(()-> FirebaseMessaging.getInstance().subscribeToTopic(topic).addOnCompleteListener(task->{
                    if(task.isSuccessful()){
                        f.topic=topic;f.enabled=true;save();if(!refresh)status("알림 ON: "+f.title());
                    }else status("Firebase 구독 실패: 네트워크/설정 확인");
                    renderItems();if(completion!=null)completion.run();
                }));
            }catch(Exception e){status("서버 등록 실패: "+e.getMessage());runOnUiThread(()->{renderItems();if(completion!=null)completion.run();});}
        });
    }
    private void openSite(){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(SITE)));}
    private void createNotificationChannel(){
        if(Build.VERSION.SDK_INT>=26){NotificationManager manager=getSystemService(NotificationManager.class);
            NotificationChannel channel=new NotificationChannel("auction","경매결과 알림",NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("즐겨찾기 경매 결과 알림");manager.createNotificationChannel(channel);}
    }
    @Override protected void onDestroy(){super.onDestroy();executor.shutdown();}
}
